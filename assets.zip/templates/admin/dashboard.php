<?php
/**
 * Admin dashboard template.
 *
 * @package WP_SiteAgent
 */

defined('ABSPATH') || exit;

$plugin = \WP_SiteAgent\Plugin::get_instance();
$registry = $plugin->get_abilities_registry();
$auth = $plugin->get_auth_manager();
$audit = $plugin->get_audit_logger();

$stats = $audit->get_stats();
$tokens = $auth->list_tokens(0);
$abilities = $registry->get_all();
$recent_logs = $audit->get_logs(['per_page' => 5, 'page' => 1]);
$mcp_endpoint = rest_url('siteagent/v1/mcp/streamable');
$site_url = get_site_url();
$is_enabled = (bool) get_option('siteagent_enabled', true);
$modules = $plugin->get_modules();
$enabled_mods = $plugin->get_enabled_modules();
?>
<div class="sa-wrap">

	<?php require SITEAGENT_PATH . 'templates/partials/header.php'; ?>

	<div class="sa-main-content">
		<div class="sa-container">

			<!-- Top Status Bar -->
			<div class="sa-top-status">
				<div class="sa-status-indicator">
					<span class="sa-status-dot"></span>
					<?php esc_html_e('MCP Server Active', 'wp-siteagent'); ?>
				</div>
				<div class="sa-status-center">
					<div class="sa-endpoint-code" id="sa-mcp-url-top">
						<?php echo esc_html(str_replace(['https://', 'http://'], '', $mcp_endpoint)); ?>
					</div>
					<button type="button" class="sa-copy-btn sa-copy-btn--inline"
						onclick="siteagent.copyText('sa-mcp-url-top')">
						<?php esc_html_e('Copy', 'wp-siteagent'); ?>
					</button>
				</div>
				<div class="sa-status-protocol">
					<?php esc_html_e('Protocol: 2024-11-05', 'wp-siteagent'); ?>
				</div>
			</div>

			<!-- Stats Cards -->
			<div class="sa-stats-grid">
				<div class="sa-stat-card sa-stat--calls">
					<div class="sa-stat-icon">
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
							stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
							<circle cx="12" cy="12" r="10"></circle>
							<line x1="12" y1="16" x2="12" y2="12"></line>
							<line x1="12" y1="8" x2="12.01" y2="8"></line>
						</svg>
					</div>
					<div class="sa-stat-value" id="stat-calls-today">
						<?php echo esc_html(number_format($stats['calls_today'])); ?>
					</div>
					<div class="sa-stat-label"><?php esc_html_e('API calls today', 'wp-siteagent'); ?></div>
					<div class="sa-stat-meta sa-meta--up">
						<span class="sa-meta-icon">↑</span>
						<span>18% vs yesterday</span>
					</div>
				</div>
				<div class="sa-stat-card sa-stat--tokens">
					<div class="sa-stat-icon">
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
							stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
							<polygon
								points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2">
							</polygon>
						</svg>
					</div>
					<div class="sa-stat-value" id="stat-tokens"><?php echo esc_html(count($tokens)); ?></div>
					<div class="sa-stat-label"><?php esc_html_e('Active tokens', 'wp-siteagent'); ?></div>
					<div class="sa-stat-meta" style="color: var(--sa-text-muted);">
						<span>2 expire in 30d</span>
					</div>
				</div>
				<div class="sa-stat-card sa-stat--abilities">
					<div class="sa-stat-icon">
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
							stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
							<line x1="3" y1="12" x2="21" y2="12"></line>
							<line x1="3" y1="6" x2="21" y2="6"></line>
							<line x1="3" y1="18" x2="21" y2="18"></line>
						</svg>
					</div>
					<div class="sa-stat-value" id="stat-abilities"><?php echo esc_html(count($abilities)); ?></div>
					<div class="sa-stat-label"><?php esc_html_e('Abilities registered', 'wp-siteagent'); ?></div>
					<?php
					$public_count = count($registry->get_mcp_public());
					?>
					<div class="sa-stat-meta" style="color: var(--sa-text-muted);">
						<span><?php echo esc_html($public_count); ?> MCP-public</span>
					</div>
				</div>
				<div class="sa-stat-card sa-stat--errors">
					<div class="sa-stat-icon">
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
							stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
							<circle cx="12" cy="12" r="10"></circle>
							<line x1="12" y1="8" x2="12" y2="12"></line>
							<line x1="12" y1="16" x2="12.01" y2="16"></line>
						</svg>
					</div>
					<div class="sa-stat-value" id="stat-errors">
						<?php echo esc_html(number_format($stats['errors_24h'])); ?>
					</div>
					<div class="sa-stat-label"><?php esc_html_e('Errors (24h)', 'wp-siteagent'); ?></div>
					<div class="sa-stat-meta sa-meta--down">
						<span>Rate: <?php echo esc_html($stats['error_rate']); ?>%</span>
					</div>
				</div>
			</div>

			<div class="sa-dashboard-body">

				<div class="sa-dashboard-main">
					<!-- Recent Audit Log -->
					<div class="sa-card" style="margin-bottom: 0; height: 100%;">
						<div class="sa-card-header" style="border-bottom: none; padding-bottom: 0;">
							<h2 style="font-size: 14px; font-weight: 600;">
								<?php esc_html_e('Recent audit log', 'wp-siteagent'); ?>
							</h2>
							<a href="<?php echo esc_url(admin_url('admin.php?page=wp-siteagent-audit')); ?>"
								class="sa-link"
								style="font-size: 12px; color: var(--sa-primary); text-decoration: none; font-weight: 500;"><?php esc_html_e('View all →', 'wp-siteagent'); ?></a>
						</div>
						<div class="sa-card-body sa-card--no-pad">
							<?php if (empty($recent_logs['logs'])): ?>
								<div class="sa-empty-state">
									<p><?php esc_html_e('No API calls yet.', 'wp-siteagent'); ?></p>
								</div>
							<?php else: ?>
								<div class="sa-table-wrap">
									<table class="sa-table" style="border-top: none;">
										<thead>
											<tr style="background: transparent;">
												<th
													style="background: transparent; border-bottom: 1px solid var(--sa-border); padding: 16px 24px; color: var(--sa-text-muted); font-size: 11px;">
													<?php esc_html_e('ABILITY', 'wp-siteagent'); ?>
												</th>
												<th
													style="background: transparent; border-bottom: 1px solid var(--sa-border); padding: 16px 24px; color: var(--sa-text-muted); font-size: 11px;">
													<?php esc_html_e('TOKEN', 'wp-siteagent'); ?>
												</th>
												<th
													style="background: transparent; border-bottom: 1px solid var(--sa-border); padding: 16px 24px; color: var(--sa-text-muted); font-size: 11px;">
													<?php esc_html_e('STATUS', 'wp-siteagent'); ?>
												</th>
												<th
													style="background: transparent; border-bottom: 1px solid var(--sa-border); padding: 16px 24px; color: var(--sa-text-muted); font-size: 11px;">
													<?php esc_html_e('TIME', 'wp-siteagent'); ?>
												</th>
											</tr>
										</thead>
										<tbody>
											<?php
											foreach ($recent_logs['logs'] as $log):
												$token_data = $auth->get_token($log['token_id']);
												$token_name = $token_data ? ($token_data['label'] ?? '—') : '—';
												?>
												<tr>
													<td style="font-size: 13px;">
														<div style="font-weight: 500;">
															<?php echo esc_html($abilities[$log['ability_name']]['label'] ?? $log['ability_name']); ?>
														</div>
													</td>
													<td style="color: var(--sa-text-secondary); font-size: 13px;">
														<?php echo esc_html($token_name); ?>
													</td>
													<td>
														<span
															class="sa-badge sa-badge--<?php echo esc_attr($log['result_status']); ?>">
															<?php echo esc_html($log['result_status']); ?>
														</span>
													</td>
													<td style="color: var(--sa-text-muted); font-size: 13px;">
														<?php echo esc_html(human_time_diff(strtotime($log['executed_at']))); ?>
														<?php esc_html_e('ago', 'wp-siteagent'); ?>
													</td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>
							<?php endif; ?>
						</div>
					</div>

					<!-- Module Status -->
					<div class="sa-card" style="margin-bottom: 0;">
						<div class="sa-card-header"
							style="border-bottom: 1px solid var(--sa-border); padding-bottom: 16px;">
							<h2 style="font-size: 14px; font-weight: 600;">
								<?php esc_html_e('Module status', 'wp-siteagent'); ?>
							</h2>
						</div>
						<div class="sa-card-body" style="padding-top: 16px;">
							<div class="sa-modules-grid">
								<?php
								$all_module_defs = [
									'content' => ['label' => __('Content', 'wp-siteagent')],
									'seo' => ['label' => __('SEO', 'wp-siteagent')],
									'woocommerce' => ['label' => __('WooCommerce', 'wp-siteagent')],
									'diagnostics' => ['label' => __('Diagnostics', 'wp-siteagent')],
									'media' => ['label' => __('Media', 'wp-siteagent')],
									'users' => ['label' => __('Users', 'wp-siteagent')],
								];
								foreach ($all_module_defs as $slug => $def):
									$module_obj = $modules[$slug] ?? null;
									$ability_count = $module_obj ? count($module_obj->get_ability_names()) : 0;
									$is_mod_enabled = in_array($slug, $enabled_mods, true);
									$status_class = $is_mod_enabled ? 'sa-module-status-dot--enabled' : '';
									?>
									<div class="sa-module-card">
										<div class="sa-module-header">
											<span class="sa-module-title">
												<?php echo esc_html($def['label']); ?>
											</span>
											<span
												class="sa-module-status-dot <?php echo esc_attr($status_class); ?>"></span>
										</div>
										<span class="sa-module-count">
											<?php printf(esc_html__('%d abilities', 'wp-siteagent'), $ability_count); ?>
										</span>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>

				<div class="sa-dashboard-sidebar">
					<!-- Connect AI Client -->
					<div class="sa-card" style="margin-bottom: 24px;">
						<div class="sa-card-header" style="border-bottom: none; padding-bottom: 8px;">
							<h2 style="font-size: 14px; font-weight: 600;">
								<?php esc_html_e('Connect AI Client', 'wp-siteagent'); ?>
							</h2>
						</div>
						<div class="sa-card-body" style="padding-top: 8px;">
							
							<!-- Token Input -->
							<div class="sa-form-group" style="margin-bottom: 20px;">
								<label for="sa-dash-token" style="font-size: 11px; font-weight: 700; margin-bottom: 8px; display: block; color: var(--sa-text-secondary); text-transform: uppercase; letter-spacing: 0.05em;"><?php esc_html_e('Your API Token', 'wp-siteagent'); ?></label>
								<input type="password" id="sa-dash-token" class="sa-input" placeholder="<?php esc_attr_e('Paste your token here...', 'wp-siteagent'); ?>" />
								<p class="sa-hint" style="margin-top: 8px; font-size: 12px;">
									<?php printf(
										esc_html__('Don\'t have a token yet? %s', 'wp-siteagent'),
										'<a href="' . esc_url(admin_url('admin.php?page=wp-siteagent-tokens')) . '" class="sa-link" style="color: var(--sa-primary); text-decoration: none; font-weight: 600;">' . esc_html__('Generate one →', 'wp-siteagent') . '</a>'
									); ?>
								</p>
							</div>

							<!-- Client Tabs -->
							<div class="sa-tab-nav" style="margin-bottom: 20px;">
								<button type="button" id="sa-dash-client-tab-claude" class="sa-tab-btn sa-tab-btn--active" onclick="siteagentDash.switchClient('claude')">
									<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>
									Claude Desktop
								</button>
								<button type="button" id="sa-dash-client-tab-cursor" class="sa-tab-btn" onclick="siteagentDash.switchClient('cursor')">
									<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
									Cursor / IDEs
								</button>
							</div>

							<!-- Claude Desktop Panel -->
							<div id="sa-dash-claude-panel">
								<div class="sa-os-tabs" style="margin-bottom: 16px;">
									<button type="button" id="sa-dash-os-tab-windows" class="sa-os-tab" onclick="siteagentDash.switchOs('windows')">Windows</button>
									<button type="button" id="sa-dash-os-tab-mac" class="sa-os-tab" onclick="siteagentDash.switchOs('mac')">macOS</button>
									<button type="button" id="sa-dash-os-tab-linux" class="sa-os-tab" onclick="siteagentDash.switchOs('linux')">Linux</button>
								</div>

								<div class="sa-tab-content sa-tab-content--active">
									<div class="sa-mcp-block" style="margin-top: 0; margin-bottom: 16px;">
										<button type="button" class="sa-copy-btn" onclick="siteagentDash.copyCommand()">
											<?php esc_html_e('Copy Command', 'wp-siteagent'); ?>
										</button>
										<pre style="margin: 0; padding: 16px;"><code id="sa-dash-command-block" style="font-size: 11px; color: #94a3b8;"><?php esc_html_e('Paste your token above to generate the command', 'wp-siteagent'); ?></code></pre>
									</div>
								</div>

								<div class="sa-node-note">
									<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
									<span><?php printf( esc_html__( 'No Node.js? Download LTS from %s first.', 'wp-siteagent' ), '<a href="https://nodejs.org/" target="_blank" rel="noopener">nodejs.org</a>' ); ?></span>
								</div>
							</div>

							<!-- Cursor Panel -->
							<div id="sa-dash-cursor-panel" style="display:none;">
								<div class="sa-form-group" style="margin-bottom: 12px;">
									<label style="font-size: 11px; font-weight: 700; margin-bottom: 4px; display: block; color: var(--sa-text-secondary);"><?php esc_html_e('MCP Server URL', 'wp-siteagent'); ?></label>
									<div class="sa-token-value-wrap" style="margin-bottom: 0;">
										<input type="text" id="sa-dash-cursor-url" class="sa-token-value" style="width: 100%; padding: 8px; font-size: 12px; border-color: var(--sa-border);" readonly value="<?php echo esc_url($mcp_endpoint); ?>" />
										<button type="button" class="sa-btn sa-btn--primary sa-btn--sm" onclick="window.siteagent.copyText('sa-dash-cursor-url')">
											<?php esc_html_e('Copy', 'wp-siteagent'); ?>
										</button>
									</div>
								</div>

								<div class="sa-form-group" style="margin-bottom: 12px;">
									<label style="font-size: 11px; font-weight: 700; margin-bottom: 4px; display: block; color: var(--sa-text-secondary);"><?php esc_html_e('Type', 'wp-siteagent'); ?></label>
									<div class="sa-token-value-wrap" style="margin-bottom: 0;">
										<input type="text" id="sa-dash-cursor-type" class="sa-token-value" style="width: 100%; padding: 8px; font-size: 12px; border-color: var(--sa-border);" readonly value="http" />
										<button type="button" class="sa-btn sa-btn--primary sa-btn--sm" onclick="window.siteagent.copyText('sa-dash-cursor-type')">
											<?php esc_html_e('Copy', 'wp-siteagent'); ?>
										</button>
									</div>
								</div>

								<div class="sa-form-group" style="margin-bottom: 12px;">
									<label style="font-size: 11px; font-weight: 700; margin-bottom: 4px; display: block; color: var(--sa-text-secondary);"><?php esc_html_e('Authorization Header', 'wp-siteagent'); ?></label>
									<div class="sa-token-value-wrap" style="margin-bottom: 0;">
										<input type="text" id="sa-dash-cursor-auth" class="sa-token-value" style="width: 100%; padding: 8px; font-size: 12px; border-color: var(--sa-border);" readonly placeholder="Bearer YOUR_TOKEN" />
										<button type="button" class="sa-btn sa-btn--primary sa-btn--sm" onclick="window.siteagent.copyText('sa-dash-cursor-auth')">
											<?php esc_html_e('Copy', 'wp-siteagent'); ?>
										</button>
									</div>
								</div>

								<p class="sa-hint" style="margin-top: 16px; font-size: 12px; line-height: 1.4; color: var(--sa-text-secondary);">
									<?php esc_html_e('In Cursor: Settings → Features → MCP Servers → Add new MCP server → set Type to HTTP, paste the URL and Authorization header.', 'wp-siteagent'); ?>
								</p>
							</div>

						</div>
					</div>


				</div>

			</div>

		</div>

	</div>

	<?php require SITEAGENT_PATH . 'templates/partials/footer.php'; ?>
</div>

</div>