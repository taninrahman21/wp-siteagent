/**
 * WP SiteAgent — Token Manager JavaScript
 *
 * Handles the generate-token modal: opening, form submission,
 * token reveal, copy, confirmation checkbox, and token revocation.
 */

/* global siteagentAdmin, siteagent */

'use strict';

(function () {

	const cfg = window.siteagentAdmin || {};
	const restUrl = cfg.restUrl || '';
	const restNonce = cfg.restNonce || '';
	const i18n = cfg.i18n || {};

	let generatedToken = null;

	window.siteagentTokens = {

		selectedOs: 'windows',


		/**
		 * Open the generate token modal.
		 */
		openGenerateModal: function () {
			const modal = document.getElementById('sa-generate-modal');
			if (!modal) return;

			// Reset form state.
			this._resetModal();

			modal.style.display = 'flex';

			// Focus label input after animation.
			setTimeout(() => {
				const label = document.getElementById('sa-token-label');
				if (label) label.focus();
			}, 150);
		},

		/**
		 * Close the generate token modal.
		 */
		closeModal: function () {
			const modal = document.getElementById('sa-generate-modal');
			if (modal) modal.style.display = 'none';

			// Reload to show new/revoked tokens in table.
			if (generatedToken) {
				window.location.reload();
			}
		},

		/**
		 * Submit token generation request.
		 */
		generateToken: function () {
			const label = document.getElementById('sa-token-label')?.value?.trim();

			if (!label) {
				if (window.siteagent && window.siteagent._showToast) {
					window.siteagent._showToast('Label is required.', 'error');
				}
				document.getElementById('sa-token-label')?.focus();
				return;
			}

			const expiresAt = document.getElementById('sa-token-expires')?.value || null;

			// Collect checked abilities.
			const abilityCheckboxes = document.querySelectorAll('input[name="abilities[]"]:checked');
			const abilities = Array.from(abilityCheckboxes).map(cb => cb.value);

			// Build payload.
			const payload = {
				label: label,
				abilities: abilities,
				expires_at: expiresAt || null
			};

			const btn = document.getElementById('sa-submit-token');
			if (btn) { btn.disabled = true; btn.textContent = i18n.saving || 'Generating…'; }

			fetch(restUrl + 'tokens', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': restNonce
				},
				body: JSON.stringify(payload)
			})
			.then(r => {
				if (!r.ok) return r.json().then(d => { throw new Error(d.message || 'Request failed'); });
				return r.json();
			})
			.then(data => {
				generatedToken = data.token;
				this._revealToken(data.token);
			})
			.catch(err => {
				if (window.siteagent && window.siteagent._showToast) {
					window.siteagent._showToast(err.message || i18n.error || 'Error occurred.', 'error');
				}
				if (btn) { btn.disabled = false; btn.textContent = 'Generate Token'; }
			});
		},

		/**
		 * Switch the active OS tab in the Claude connection section.
		 * 
		 * @param {string} os - 'windows', 'mac', 'linux'
		 */
		switchOsTab: function(os) {
			window.siteagentTokens.selectedOs = os;

			// Update tab styles.
			const tabs = ['windows', 'mac', 'linux'];
			tabs.forEach(t => {
				const el = document.getElementById('sa-os-tab-' + t);
				if (el) {
					if (t === os) el.classList.add('sa-os-tab--active');
					else el.classList.remove('sa-os-tab--active');
				}
			});

			// Update description and button label.
			const desc = document.getElementById('sa-os-desc');
			const label = document.getElementById('sa-copy-claude-label');
			
			if (os === 'windows') {
				if (desc) desc.textContent = 'Connect this site to Claude Desktop automatically by running a simple PowerShell command.';
				if (label) label.textContent = 'Copy PowerShell Command';
			} else {
				const osName = os === 'mac' ? 'macOS' : 'Linux';
				if (desc) desc.textContent = `Connect this site to Claude Desktop automatically by running a simple Terminal command on ${osName}.`;
				if (label) label.textContent = 'Copy Terminal Command';
			}

			// Update the hidden copy source if a token exists.
			if (generatedToken) {
				const endpoint = cfg.mcpEndpoint || '';
				const token = generatedToken;
				let command = '';

				if (os === 'windows') {
					command = `npm install -g mcp-remote; $npmRoot = (npm root -g).Trim(); $configPath = "$env:AppData\\Claude\\claude_desktop_config.json"; if (!(Test-Path (Split-Path $configPath))) { New-Item -ItemType Directory -Path (Split-Path $configPath) -Force }; $config = if (Test-Path $configPath) { Get-Content $configPath | ConvertFrom-Json } else { [PSCustomObject]@{ mcpServers = @{} } }; if (!$config.mcpServers) { $config | Add-Member -MemberType NoteProperty -Name mcpServers -Value @{} }; $config.mcpServers.'wp-siteagent' = @{ command = 'node'; args = @("$npmRoot/mcp-remote/dist/proxy.js", "${endpoint}", "--header", "Authorization: Bearer ${token}") }; $config | ConvertTo-Json -Depth 10 | Set-Content $configPath; Write-Host "Successfully connected to Claude Desktop! Please restart the app." -ForegroundColor Green`;
				} else {
					const configHome = os === 'mac' ? '$HOME/Library/Application Support/Claude' : '$HOME/.config/Claude';
					const configPath = configHome + '/claude_desktop_config.json';
					command = `npm install -g mcp-remote && NPM_ROOT=$(npm root -g) && CONFIG_PATH="${configPath}" && mkdir -p "$(dirname "$CONFIG_PATH")" && [ -f "$CONFIG_PATH" ] || echo '{"mcpServers":{}}' > "$CONFIG_PATH" && node -e "const fs=require('fs'); const cfg=JSON.parse(fs.readFileSync('$CONFIG_PATH','utf8')); cfg.mcpServers=cfg.mcpServers||{}; cfg.mcpServers['wp-siteagent']={command:'node',args:['$NPM_ROOT/mcp-remote/dist/proxy.js','${endpoint}','--header','Authorization: Bearer ${token}']}; fs.writeFileSync('$CONFIG_PATH',JSON.stringify(cfg,null,2));" && echo "Successfully connected to Claude Desktop! Please restart the app."`;
				}

				const target = document.getElementById('sa-dynamic-copy-target');
				if (target) {
					target.value = command;
				}
			}
		},

		/**
		 * Revoke a token via REST API.
		 *
		 * @param {number} tokenId  - Token ID to revoke.
		 * @param {string} label    - Token label for confirmation.
		 */
		revokeToken: function (tokenId, label) {
			const msg = (i18n.confirmRevoke || 'Are you sure you want to revoke this token?')
				.replace('this token', '"' + label + '"');

			if (!confirm(msg)) return;

			fetch(restUrl + 'tokens/' + tokenId, {
				method: 'DELETE',
				headers: { 'X-WP-Nonce': restNonce }
			})
			.then(r => r.json())
			.then(data => {
				if (data.revoked) {
					if (window.siteagent && window.siteagent._showToast) {
						window.siteagent._showToast('Token revoked.');
					}
					setTimeout(() => window.location.reload(), 1000);
				} else {
					if (window.siteagent && window.siteagent._showToast) {
						window.siteagent._showToast(data.message || i18n.error, 'error');
					}
				}
			})
			.catch(() => {
				if (window.siteagent && window.siteagent._showToast) {
					window.siteagent._showToast(i18n.error || 'Error.', 'error');
				}
			});
		},

		/**
		 * Show the token value and switch UI to reveal mode.
		 *
		 * @param {string} token - Raw token string to reveal.
		 * @private
		 */
		_revealToken: function (token) {
			// Hide the generate form / button.
			const form = document.getElementById('sa-generate-token-form');
			if (form) {
				const exemptIds = ['sa-confirm-copied', 'sa-copy-token-btn', 'sa-copy-claude-btn'];
				Array.from(form.elements).forEach(el => {
					if (!exemptIds.includes(el.id)) {
						el.disabled = true;
					} else {
						el.disabled = false;
					}
				});
			}

			const submitBtn = document.getElementById('sa-submit-token');
			if (submitBtn) submitBtn.style.display = 'none';

			const revealArea = document.getElementById('sa-token-reveal');
			if (revealArea) revealArea.style.display = 'block';

			const tokenEl = document.getElementById('sa-new-token-value');
			if (tokenEl) tokenEl.textContent = token;

			// Attach copy handlers programmatically
			const tokenBtn = document.getElementById('sa-copy-token-btn');
			if (tokenBtn) {
				tokenBtn.onclick = () => {
					window.siteagent.copyText('sa-new-token-value');
				};
			}

			const claudeBtn = document.getElementById('sa-copy-claude-btn');
			if (claudeBtn) {
				claudeBtn.onclick = () => {
					window.siteagent.copyText('sa-dynamic-copy-target');
				};
			}

			// Show done button; enable when checkbox is checked.
			const doneBtn = document.getElementById('sa-close-after-copy');
			if (doneBtn) doneBtn.style.display = 'inline-flex';

			const checkbox = document.getElementById('sa-confirm-copied');
			if (checkbox) {
				checkbox.addEventListener('change', function () {
					if (doneBtn) doneBtn.disabled = !this.checked;
				});
			}

			// Initialize the dynamic copy source for Claude command.
			this.switchOsTab(window.siteagentTokens.selectedOs || 'windows');
		},

		/**
		 * Reset the modal form back to initial state.
		 *
		 * @private
		 */
		_resetModal: function () {
			generatedToken = null;

			const form = document.getElementById('sa-generate-token-form');
			if (form) form.reset();

			// Reset OS selection.
			this.switchOsTab('windows');


			const reveal = document.getElementById('sa-token-reveal');
			if (reveal) reveal.style.display = 'none';

			const submitBtn = document.getElementById('sa-submit-token');
			if (submitBtn) { submitBtn.style.display = 'inline-flex'; submitBtn.disabled = false; submitBtn.textContent = 'Generate Token'; }

			const doneBtn = document.getElementById('sa-close-after-copy');
			if (doneBtn) { doneBtn.style.display = 'none'; doneBtn.disabled = true; }

			// Re-enable form elements.
			if (form) {
				Array.from(form.elements).forEach(el => { el.disabled = false; });
			}
		}
	};

}());
