<?php
/**
 * Admin page header partial.
 *
 * @package WP_SiteAgent
 */

defined( 'ABSPATH' ) || exit;

$current_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : 'wp-siteagent';
?>
<div class="sa-header">
	<div class="sa-header-brand">
		<div class="sa-logo">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32" fill="currentColor">
				<path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7H4a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2M7 14a2 2 0 0 1 2 2 2 2 0 0 1-2 2 2 2 0 0 1-2-2 2 2 0 0 1 2-2m10 0a2 2 0 0 1 2 2 2 2 0 0 1-2 2 2 2 0 0 1-2-2 2 2 0 0 1 2-2m-5 2a2 2 0 0 1 2 2 2 2 0 0 1-2 2 2 2 0 0 1-2-2 2 2 0 0 1 2-2z"/>
			</svg>
		</div>
		<div class="sa-header-title">
			<h1>WP SiteAgent</h1>
			<p><?php esc_html_e( 'AI Agent Command Layer', 'wp-siteagent' ); ?></p>
		</div>
	</div>
	<nav class="sa-nav">
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent' ) ); ?>"
			class="sa-nav-link <?php echo 'wp-siteagent' === $current_page ? 'sa-nav-link--active' : ''; ?>">
			<?php esc_html_e( 'Dashboard', 'wp-siteagent' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-abilities' ) ); ?>"
			class="sa-nav-link <?php echo 'wp-siteagent-abilities' === $current_page ? 'sa-nav-link--active' : ''; ?>">
			<?php esc_html_e( 'Abilities', 'wp-siteagent' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-tokens' ) ); ?>"
			class="sa-nav-link <?php echo 'wp-siteagent-tokens' === $current_page ? 'sa-nav-link--active' : ''; ?>">
			<?php esc_html_e( 'API Tokens', 'wp-siteagent' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-audit' ) ); ?>"
			class="sa-nav-link <?php echo 'wp-siteagent-audit' === $current_page ? 'sa-nav-link--active' : ''; ?>">
			<?php esc_html_e( 'Audit Log', 'wp-siteagent' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-settings' ) ); ?>"
			class="sa-nav-link <?php echo 'wp-siteagent-settings' === $current_page ? 'sa-nav-link--active' : ''; ?>">
			<?php esc_html_e( 'Settings', 'wp-siteagent' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-tools' ) ); ?>"
			class="sa-nav-link <?php echo 'wp-siteagent-tools' === $current_page ? 'sa-nav-link--active' : ''; ?>">
			<?php esc_html_e( 'Tools', 'wp-siteagent' ); ?>
		</a>
	</nav>
</div>
