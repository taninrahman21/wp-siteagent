<?php
/**
 * Admin page footer partial.
 *
 * @package WP_SiteAgent
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="sa-footer">
	<div class="sa-footer-left">
		<span>WP SiteAgent v<?php echo esc_html( SITEAGENT_VERSION ); ?></span>
		&bull;
		<a href="https://modelcontextprotocol.io" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'MCP Specification', 'wp-siteagent' ); ?></a>
	</div>
	<div class="sa-footer-right">
		<span><?php esc_html_e( 'WordPress', 'wp-siteagent' ); ?> <?php echo esc_html( get_bloginfo( 'version' ) ); ?></span>
		&bull;
		<span>PHP <?php echo esc_html( PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION ); ?></span>
	</div>
</div>
