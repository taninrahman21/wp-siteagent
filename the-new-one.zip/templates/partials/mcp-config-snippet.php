<?php
/**
 * MCP configuration snippet partial.
 *
 * @package WP_SiteAgent
 */

defined( 'ABSPATH' ) || exit;

$mcp_endpoint = rest_url( 'siteagent/v1/mcp/streamable' );
$config_json  = json_encode( [
	'mcpServers' => [
		'wp-siteagent' => [
			'type'    => 'http',
			'url'     => $mcp_endpoint,
			'headers' => [
				'Authorization' => 'Bearer YOUR_TOKEN_HERE',
			],
		],
	],
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
?>
<div class="sa-mcp-snippet">
	<div class="sa-snippet-header">
		<div class="sa-snippet-dots">
			<span></span><span></span><span></span>
		</div>
		<div class="sa-snippet-title">claude_desktop_config.json</div>
		<button type="button" id="sa-copy-config-btn" class="sa-btn sa-btn--ghost sa-btn--sm" onclick="siteagent.copyMcpConfig()">
			<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
				<rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
				<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
			</svg>
			<span id="sa-copy-config-text"><?php esc_html_e( 'Copy', 'wp-siteagent' ); ?></span>
		</button>
	</div>
	<pre id="sa-mcp-config-code" class="sa-snippet-code"><code><?php echo esc_html( $config_json ); ?></code></pre>
	<div class="sa-snippet-footer">
		<p>
			<?php esc_html_e( 'Replace', 'wp-siteagent' ); ?>
			<code>YOUR_TOKEN_HERE</code>
			<?php esc_html_e( 'with a token generated in the', 'wp-siteagent' ); ?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-tokens' ) ); ?>"><?php esc_html_e( 'API Tokens', 'wp-siteagent' ); ?></a>
			<?php esc_html_e( 'page.', 'wp-siteagent' ); ?>
		</p>
	</div>
</div>
