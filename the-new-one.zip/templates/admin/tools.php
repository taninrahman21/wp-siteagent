<?php
/**
 * Tools page template.
 *
 * @package WP_SiteAgent
 */

defined( 'ABSPATH' ) || exit;

$mcp_endpoint = rest_url( 'siteagent/v1/mcp/streamable' );
$status_url   = rest_url( 'siteagent/v1/status' );
?>
<div class="sa-wrap">
	<?php require SITEAGENT_PATH . 'templates/partials/header.php'; ?>

	<div class="sa-page-header">
		<h2><?php esc_html_e( 'Diagnostic Tools', 'wp-siteagent' ); ?></h2>
	</div>

	<!-- Endpoint Tester -->
	<div class="sa-card">
		<div class="sa-card-header">
			<h3><?php esc_html_e( 'MCP Endpoint Tester', 'wp-siteagent' ); ?></h3>
		</div>
		<div class="sa-card-body">
			<p><?php esc_html_e( 'Test the MCP initialize method to verify the endpoint is working correctly.', 'wp-siteagent' ); ?></p>
			<div class="sa-form-row">
				<label for="sa-test-token"><?php esc_html_e( 'Bearer Token', 'wp-siteagent' ); ?></label>
				<div class="sa-form-control">
					<input type="text" id="sa-test-token" class="sa-input" placeholder="<?php esc_attr_e( 'Paste your raw token here…', 'wp-siteagent' ); ?>" />
					<button type="button" class="sa-btn sa-btn--primary" onclick="siteagentTools.testEndpoint()">
						<?php esc_html_e( 'Test Initialize', 'wp-siteagent' ); ?>
					</button>
				</div>
			</div>
			<pre id="sa-test-result" class="sa-snippet-code sa-test-output" style="display:none;"></pre>
		</div>
	</div>

	<!-- Status Check -->
	<div class="sa-card">
		<div class="sa-card-header">
			<h3><?php esc_html_e( 'System Status', 'wp-siteagent' ); ?></h3>
		</div>
		<div class="sa-card-body">
			<div class="sa-system-checks">
				<div class="sa-check-row">
					<span class="sa-check-label"><?php esc_html_e( 'PHP Version', 'wp-siteagent' ); ?></span>
					<span class="sa-check-value <?php echo version_compare( PHP_VERSION, '8.1', '>=' ) ? 'sa-check--pass' : 'sa-check--fail'; ?>">
						PHP <?php echo esc_html( PHP_VERSION ); ?>
						<?php echo version_compare( PHP_VERSION, '8.1', '>=' ) ? '✓' : '✗ (requires 8.1+)'; ?>
					</span>
				</div>
				<div class="sa-check-row">
					<span class="sa-check-label"><?php esc_html_e( 'WordPress Version', 'wp-siteagent' ); ?></span>
					<span class="sa-check-value <?php echo version_compare( get_bloginfo( 'version' ), '6.9', '>=' ) ? 'sa-check--pass' : 'sa-check--warn'; ?>">
						WordPress <?php echo esc_html( get_bloginfo( 'version' ) ); ?>
						<?php echo version_compare( get_bloginfo( 'version' ), '6.9', '>=' ) ? '✓' : '⚠ (Abilities API requires 6.9+)'; ?>
					</span>
				</div>
				<div class="sa-check-row">
					<span class="sa-check-label"><?php esc_html_e( 'HTTPS', 'wp-siteagent' ); ?></span>
					<span class="sa-check-value <?php echo is_ssl() ? 'sa-check--pass' : 'sa-check--warn'; ?>">
						<?php echo is_ssl() ? '✓ ' . esc_html__( 'HTTPS Active', 'wp-siteagent' ) : '⚠ ' . esc_html__( 'HTTP Only — MCP clients prefer HTTPS', 'wp-siteagent' ); ?>
					</span>
				</div>
				<div class="sa-check-row">
					<span class="sa-check-label"><?php esc_html_e( 'REST API', 'wp-siteagent' ); ?></span>
					<span class="sa-check-value" id="sa-rest-check">
						<?php esc_html_e( 'Checking…', 'wp-siteagent' ); ?>
					</span>
				</div>
				<div class="sa-check-row">
					<span class="sa-check-label"><?php esc_html_e( 'DB Tables', 'wp-siteagent' ); ?></span>
					<?php
					global $wpdb;
					$tables = [ 'siteagent_tokens', 'siteagent_audit_log', 'siteagent_rate_limits' ];
					$all_ok = true;
					foreach ( $tables as $t ) {
						if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->prefix . $t ) ) !== $wpdb->prefix . $t ) {
							$all_ok = false;
						}
					}
					?>
					<span class="sa-check-value <?php echo $all_ok ? 'sa-check--pass' : 'sa-check--fail'; ?>">
						<?php echo $all_ok ? '✓ ' . esc_html__( 'All 3 tables found', 'wp-siteagent' ) : '✗ ' . esc_html__( 'Missing tables — deactivate and reactivate plugin', 'wp-siteagent' ); ?>
					</span>
				</div>
				<div class="sa-check-row">
					<span class="sa-check-label"><?php esc_html_e( 'OpenSSL (token gen)', 'wp-siteagent' ); ?></span>
					<span class="sa-check-value <?php echo extension_loaded( 'openssl' ) ? 'sa-check--pass' : 'sa-check--fail'; ?>">
						<?php echo extension_loaded( 'openssl' ) ? '✓ ' . esc_html__( 'Loaded', 'wp-siteagent' ) : '✗ ' . esc_html__( 'Missing — required for secure token generation', 'wp-siteagent' ); ?>
					</span>
				</div>
			</div>
		</div>
	</div>

	<!-- MCP Endpoint URLs -->
	<div class="sa-card">
		<div class="sa-card-header">
			<h3><?php esc_html_e( 'API Endpoints Reference', 'wp-siteagent' ); ?></h3>
		</div>
		<div class="sa-card-body">
			<table class="sa-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Method', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'URL', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'Description', 'wp-siteagent' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$endpoints = [
						[ 'GET',  rest_url( 'siteagent/v1/status' ), __( 'Server status (public)', 'wp-siteagent' ) ],
						[ 'POST', rest_url( 'siteagent/v1/mcp/streamable' ), __( 'MCP JSON-RPC endpoint (auth required)', 'wp-siteagent' ) ],
						[ 'GET',  rest_url( 'siteagent/v1/abilities' ), __( 'List registered abilities', 'wp-siteagent' ) ],
						[ 'GET',  rest_url( 'siteagent/v1/tokens' ), __( 'List API tokens', 'wp-siteagent' ) ],
						[ 'POST', rest_url( 'siteagent/v1/tokens' ), __( 'Generate new token', 'wp-siteagent' ) ],
						[ 'GET',  rest_url( 'siteagent/v1/audit-log' ), __( 'Audit log', 'wp-siteagent' ) ],
						[ 'POST', rest_url( 'siteagent/v1/cache/clear' ), __( 'Clear caches', 'wp-siteagent' ) ],
					];
					foreach ( $endpoints as $ep ) :
					?>
					<tr>
						<td><span class="sa-method-badge sa-method--<?php echo strtolower( esc_attr( $ep[0] ) ); ?>"><?php echo esc_html( $ep[0] ); ?></span></td>
						<td><code><?php echo esc_html( $ep[1] ); ?></code></td>
						<td><?php echo esc_html( $ep[2] ); ?></td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>

	<script>
	document.addEventListener('DOMContentLoaded', function() {
		// Check REST API availability.
		fetch('<?php echo esc_url( rest_url( 'siteagent/v1/status' ) ); ?>')
			.then(r => r.json())
			.then(data => {
				const el = document.getElementById('sa-rest-check');
				if (el) {
					el.className = 'sa-check-value sa-check--pass';
					el.textContent = '✓ REST API reachable (status: ' + (data.status || 'ok') + ')';
				}
			})
			.catch(() => {
				const el = document.getElementById('sa-rest-check');
				if (el) {
					el.className = 'sa-check-value sa-check--fail';
					el.textContent = '✗ REST API unreachable';
				}
			});

		// Tools namespace.
		window.siteagentTools = {
			testEndpoint: function() {
				const token = document.getElementById('sa-test-token').value;
				const output = document.getElementById('sa-test-result');
				output.style.display = 'block';
				output.textContent = 'Testing…';

				const payload = { jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2024-11-05', clientInfo: { name: 'WP SiteAgent Tools', version: '1.0.0' } } };

				fetch('<?php echo esc_url( $mcp_endpoint ); ?>', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer ' + token
					},
					body: JSON.stringify(payload)
				})
				.then(r => r.json())
				.then(data => { output.textContent = JSON.stringify(data, null, 2); })
				.catch(err => { output.textContent = 'Error: ' + err.message; });
			}
		};
	});
	</script>

	<?php require SITEAGENT_PATH . 'templates/partials/footer.php'; ?>
</div>
