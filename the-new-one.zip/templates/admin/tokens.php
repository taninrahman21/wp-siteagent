<?php
/**
 * Token management template.
 *
 * @package WP_SiteAgent
 */

defined( 'ABSPATH' ) || exit;

$plugin   = \WP_SiteAgent\Plugin::get_instance();
$auth     = $plugin->get_auth_manager();
$registry = $plugin->get_abilities_registry();
$tokens   = $auth->list_tokens( 0 );
$abilities = array_keys( $registry->get_all() );
?>
<div class="sa-wrap">
	<?php require SITEAGENT_PATH . 'templates/partials/header.php'; ?>

	<div class="sa-page-header">
		<h2><?php esc_html_e( 'API Tokens', 'wp-siteagent' ); ?></h2>
		<button type="button" id="sa-generate-token-btn" class="sa-btn sa-btn--primary" onclick="siteagentTokens.openGenerateModal()">
			+ <?php esc_html_e( 'Generate Token', 'wp-siteagent' ); ?>
		</button>
	</div>

	<!-- Tokens Table -->
	<div class="sa-card">
		<div class="sa-card-body sa-card--no-pad">
			<?php if ( empty( $tokens ) ) : ?>
			<div class="sa-empty-state">
				<p><?php esc_html_e( 'No tokens yet. Generate your first token to connect an MCP client.', 'wp-siteagent' ); ?></p>
			</div>
			<?php else : ?>
			<table class="sa-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Label', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'Created', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'Expires', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'Last Used', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'Abilities', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'Status', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'wp-siteagent' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $tokens as $token ) :
					$is_active  = (int) $token['is_active'] === 1;
					$is_expired = ! empty( $token['expires_at'] ) && strtotime( $token['expires_at'] ) < time();
					$status     = ! $is_active ? 'revoked' : ( $is_expired ? 'expired' : 'active' );
					$abilities_list = empty( $token['abilities'] ) ? __( 'All abilities', 'wp-siteagent' ) : implode( ', ', array_slice( $token['abilities'], 0, 3 ) ) . ( count( $token['abilities'] ) > 3 ? ' +' . ( count( $token['abilities'] ) - 3 ) . ' more' : '' );
				?>
				<tr>
					<td><strong><?php echo esc_html( $token['label'] ); ?></strong></td>
					<td><?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( $token['created_at'] ) ) ); ?></td>
					<td><?php echo $token['expires_at'] ? esc_html( wp_date( get_option( 'date_format' ), strtotime( $token['expires_at'] ) ) ) : '<em>' . esc_html__( 'Never', 'wp-siteagent' ) . '</em>'; ?></td>
					<td><?php echo $token['last_used'] ? esc_html( human_time_diff( strtotime( $token['last_used'] ) ) . ' ' . __( 'ago', 'wp-siteagent' ) ) : '<em>' . esc_html__( 'Never', 'wp-siteagent' ) . '</em>'; ?></td>
					<td class="sa-td--abilities" title="<?php echo isset( $token['abilities'] ) ? esc_attr( implode( ', ', $token['abilities'] ) ) : ''; ?>"><?php echo esc_html( $abilities_list ); ?></td>
					<td><span class="sa-badge sa-badge--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $status ); ?></span></td>
					<td class="sa-td--actions">
						<?php if ( $is_active && ! $is_expired ) : ?>
						<button type="button"
							class="sa-btn sa-btn--danger sa-btn--sm"
							onclick="siteagentTokens.revokeToken(<?php echo absint( $token['id'] ); ?>, '<?php echo esc_attr( $token['label'] ); ?>')">
							<?php esc_html_e( 'Revoke', 'wp-siteagent' ); ?>
						</button>
						<?php endif; ?>
					</td>
				</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>
		</div>
	</div>

	<!-- Generate Token Modal -->
	<div id="sa-generate-modal" class="sa-modal-overlay" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="sa-modal-title">
		<div class="sa-modal">
			<div class="sa-modal-header">
				<h3 id="sa-modal-title"><?php esc_html_e( 'Generate API Token', 'wp-siteagent' ); ?></h3>
				<button type="button" class="sa-modal-close" onclick="siteagentTokens.closeModal()">&times;</button>
			</div>
			<div class="sa-modal-body">
				<form id="sa-generate-token-form">
					<div class="sa-form-group">
						<label for="sa-token-label"><?php esc_html_e( 'Label', 'wp-siteagent' ); ?> <span class="sa-required">*</span></label>
						<input type="text" id="sa-token-label" name="label" class="sa-input" placeholder="<?php esc_attr_e( 'e.g. Claude Desktop - Home', 'wp-siteagent' ); ?>" required />
					</div>
					<div class="sa-form-group">
						<label for="sa-token-expires"><?php esc_html_e( 'Expires', 'wp-siteagent' ); ?></label>
						<input type="date" id="sa-token-expires" name="expires_at" class="sa-input" min="<?php echo esc_attr( gmdate( 'Y-m-d', strtotime( '+1 day' ) ) ); ?>" />
						<p class="sa-hint"><?php esc_html_e( 'Leave blank for no expiry.', 'wp-siteagent' ); ?></p>
					</div>
					<div class="sa-form-group">
						<label><?php esc_html_e( 'Ability Restrictions', 'wp-siteagent' ); ?></label>
						<p class="sa-hint"><?php esc_html_e( 'Leave all unchecked to allow all abilities.', 'wp-siteagent' ); ?></p>
						<div class="sa-abilities-check">
							<?php foreach ( $abilities as $ability_name ) : ?>
							<label class="sa-checkbox-label">
								<input type="checkbox" name="abilities[]" value="<?php echo esc_attr( $ability_name ); ?>" />
								<code><?php echo esc_html( $ability_name ); ?></code>
							</label>
							<?php endforeach; ?>
						</div>
					</div>
					<div id="sa-token-reveal" class="sa-token-reveal" style="display:none;">
						<div class="sa-token-reveal-warning">
							⚠️ <?php esc_html_e( 'Copy this token now — it will NEVER be shown again!', 'wp-siteagent' ); ?>
						</div>
						<div class="sa-token-value-wrap">
							<code id="sa-new-token-value" class="sa-token-value"></code>
							<button type="button" class="sa-btn sa-btn--primary sa-btn--sm" onclick="siteagentTokens.copyNewToken()">
								<?php esc_html_e( 'Copy Token', 'wp-siteagent' ); ?>
							</button>
						</div>
						<label class="sa-checkbox-label sa-confirm-copy">
							<input type="checkbox" id="sa-confirm-copied" />
							<?php esc_html_e( 'I have copied the token and saved it securely.', 'wp-siteagent' ); ?>
						</label>
					</div>
				</form>
			</div>
			<div class="sa-modal-footer">
				<button type="button" class="sa-btn sa-btn--ghost" onclick="siteagentTokens.closeModal()"><?php esc_html_e( 'Cancel', 'wp-siteagent' ); ?></button>
				<button type="button" id="sa-submit-token" class="sa-btn sa-btn--primary" onclick="siteagentTokens.generateToken()">
					<?php esc_html_e( 'Generate Token', 'wp-siteagent' ); ?>
				</button>
				<button type="button" id="sa-close-after-copy" class="sa-btn sa-btn--success" style="display:none;" onclick="siteagentTokens.closeModal()" disabled>
					<?php esc_html_e( 'Done — Close', 'wp-siteagent' ); ?>
				</button>
			</div>
		</div>
	</div>

	<?php require SITEAGENT_PATH . 'templates/partials/footer.php'; ?>
</div>
