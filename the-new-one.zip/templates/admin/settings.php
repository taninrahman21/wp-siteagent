<?php
/**
 * Settings page template.
 *
 * @package WP_SiteAgent
 */

defined( 'ABSPATH' ) || exit;

$plugin        = \WP_SiteAgent\Plugin::get_instance();
$enabled_mods  = $plugin->get_enabled_modules();

$all_modules = [
	'content'     => [ 'label' => __( 'Content', 'wp-siteagent' ),     'desc' => __( 'Posts, pages, CPT management', 'wp-siteagent' ),         'count' => 9 ],
	'seo'         => [ 'label' => __( 'SEO', 'wp-siteagent' ),         'desc' => __( 'SEO analysis and meta management', 'wp-siteagent' ),     'count' => 6 ],
	'diagnostics' => [ 'label' => __( 'Diagnostics', 'wp-siteagent' ), 'desc' => __( 'Site health, error logs, cron', 'wp-siteagent' ),        'count' => 7 ],
	'media'       => [ 'label' => __( 'Media', 'wp-siteagent' ),       'desc' => __( 'Media library management', 'wp-siteagent' ),             'count' => 6 ],
	'users'       => [ 'label' => __( 'Users', 'wp-siteagent' ),       'desc' => __( 'User management', 'wp-siteagent' ),                      'count' => 6 ],
	'woocommerce' => [ 'label' => __( 'WooCommerce', 'wp-siteagent' ), 'desc' => __( 'Products, orders, coupons (requires WooCommerce)', 'wp-siteagent' ), 'count' => 12 ],
];
?>
<div class="sa-wrap">
	<?php require SITEAGENT_PATH . 'templates/partials/header.php'; ?>

	<div class="sa-page-header">
		<h2><?php esc_html_e( 'Settings', 'wp-siteagent' ); ?></h2>
	</div>

	<form method="post" action="options.php">
		<?php settings_fields( 'siteagent_settings' ); ?>

		<!-- General Settings -->
		<div class="sa-card sa-settings-section">
			<div class="sa-card-header">
				<h3><?php esc_html_e( 'General', 'wp-siteagent' ); ?></h3>
			</div>
			<div class="sa-card-body">
				<div class="sa-form-row">
					<label><?php esc_html_e( 'MCP Server', 'wp-siteagent' ); ?></label>
					<div class="sa-form-control">
						<label class="sa-toggle">
							<input type="checkbox" name="siteagent_enabled" value="1" <?php checked( get_option( 'siteagent_enabled', true ) ); ?> />
							<span class="sa-toggle-slider"></span>
						</label>
						<span class="sa-toggle-label"><?php esc_html_e( 'Enable MCP server endpoint', 'wp-siteagent' ); ?></span>
					</div>
				</div>
				<div class="sa-form-row">
					<label for="siteagent_display_name"><?php esc_html_e( 'Agent Display Name', 'wp-siteagent' ); ?></label>
					<div class="sa-form-control">
						<input type="text" id="siteagent_display_name" name="siteagent_display_name"
							value="<?php echo esc_attr( get_option( 'siteagent_display_name', '' ) ); ?>"
							class="sa-input" />
						<p class="sa-hint"><?php esc_html_e( 'The name shown to AI clients in the MCP initialize response.', 'wp-siteagent' ); ?></p>
					</div>
				</div>
			</div>
		</div>

		<!-- Rate Limiting -->
		<div class="sa-card sa-settings-section">
			<div class="sa-card-header">
				<h3><?php esc_html_e( 'Rate Limiting', 'wp-siteagent' ); ?></h3>
			</div>
			<div class="sa-card-body">
				<div class="sa-form-row">
					<label for="siteagent_hourly_limit"><?php esc_html_e( 'Hourly Limit', 'wp-siteagent' ); ?></label>
					<div class="sa-form-control">
						<input type="number" id="siteagent_hourly_limit" name="siteagent_hourly_limit"
							value="<?php echo esc_attr( get_option( 'siteagent_hourly_limit', 200 ) ); ?>"
							class="sa-input sa-input--narrow" min="1" max="10000" />
						<span class="sa-unit"><?php esc_html_e( 'requests/hour per token', 'wp-siteagent' ); ?></span>
					</div>
				</div>
				<div class="sa-form-row">
					<label for="siteagent_daily_limit"><?php esc_html_e( 'Daily Limit', 'wp-siteagent' ); ?></label>
					<div class="sa-form-control">
						<input type="number" id="siteagent_daily_limit" name="siteagent_daily_limit"
							value="<?php echo esc_attr( get_option( 'siteagent_daily_limit', 2000 ) ); ?>"
							class="sa-input sa-input--narrow" min="1" max="100000" />
						<span class="sa-unit"><?php esc_html_e( 'requests/day per token', 'wp-siteagent' ); ?></span>
					</div>
				</div>
			</div>
		</div>

		<!-- Modules -->
		<div class="sa-card sa-settings-section">
			<div class="sa-card-header">
				<h3><?php esc_html_e( 'Modules', 'wp-siteagent' ); ?></h3>
			</div>
			<div class="sa-card-body">
				<div class="sa-modules-settings">
					<?php foreach ( $all_modules as $slug => $mod ) :
						$wc_available = $slug !== 'woocommerce' || class_exists( 'WooCommerce' );
					?>
					<div class="sa-module-setting <?php echo ! $wc_available ? 'sa-module-setting--disabled' : ''; ?>">
						<label class="sa-toggle">
							<input type="checkbox"
								name="siteagent_enabled_modules[]"
								value="<?php echo esc_attr( $slug ); ?>"
								<?php checked( in_array( $slug, $enabled_mods, true ) ); ?>
								<?php echo ! $wc_available ? 'disabled' : ''; ?>
							/>
							<span class="sa-toggle-slider"></span>
						</label>
						<div class="sa-module-info">
							<strong><?php echo esc_html( $mod['label'] ); ?></strong>
							<span class="sa-module-count-badge"><?php echo esc_html( $mod['count'] ); ?> <?php esc_html_e( 'abilities', 'wp-siteagent' ); ?></span>
							<p class="sa-hint"><?php echo esc_html( $mod['desc'] ); ?></p>
							<?php if ( ! $wc_available ) : ?>
							<p class="sa-notice sa-notice--warning"><?php esc_html_e( 'WooCommerce plugin is not active.', 'wp-siteagent' ); ?></p>
							<?php endif; ?>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>

		<!-- Cache -->
		<div class="sa-card sa-settings-section">
			<div class="sa-card-header">
				<h3><?php esc_html_e( 'Cache', 'wp-siteagent' ); ?></h3>
			</div>
			<div class="sa-card-body">
				<div class="sa-form-row">
					<label for="siteagent_cache_ttl"><?php esc_html_e( 'Cache TTL', 'wp-siteagent' ); ?></label>
					<div class="sa-form-control">
						<input type="number" id="siteagent_cache_ttl" name="siteagent_cache_ttl"
							value="<?php echo esc_attr( get_option( 'siteagent_cache_ttl', 3600 ) ); ?>"
							class="sa-input sa-input--narrow" min="60" max="86400" />
						<span class="sa-unit"><?php esc_html_e( 'seconds', 'wp-siteagent' ); ?></span>
					</div>
				</div>
				<div class="sa-form-row">
					<label><?php esc_html_e( 'Clear Cache', 'wp-siteagent' ); ?></label>
					<div class="sa-form-control">
						<button type="button" id="sa-clear-cache-btn" class="sa-btn sa-btn--ghost" onclick="siteagent.clearCache()">
							<?php esc_html_e( 'Clear All Caches', 'wp-siteagent' ); ?>
						</button>
						<span id="sa-cache-result" class="sa-inline-result"></span>
					</div>
				</div>
			</div>
		</div>

		<!-- Logging -->
		<div class="sa-card sa-settings-section">
			<div class="sa-card-header">
				<h3><?php esc_html_e( 'Logging', 'wp-siteagent' ); ?></h3>
			</div>
			<div class="sa-card-body">
				<div class="sa-form-row">
					<label for="siteagent_log_retention_days"><?php esc_html_e( 'Log Retention', 'wp-siteagent' ); ?></label>
					<div class="sa-form-control">
						<input type="number" id="siteagent_log_retention_days" name="siteagent_log_retention_days"
							value="<?php echo esc_attr( get_option( 'siteagent_log_retention_days', 30 ) ); ?>"
							class="sa-input sa-input--narrow" min="1" max="365" />
						<span class="sa-unit"><?php esc_html_e( 'days', 'wp-siteagent' ); ?></span>
					</div>
				</div>
				<div class="sa-form-row">
					<label for="siteagent_log_level"><?php esc_html_e( 'Log Level', 'wp-siteagent' ); ?></label>
					<div class="sa-form-control">
						<select id="siteagent_log_level" name="siteagent_log_level" class="sa-select">
							<option value="all" <?php selected( get_option( 'siteagent_log_level', 'all' ), 'all' ); ?>><?php esc_html_e( 'All calls', 'wp-siteagent' ); ?></option>
							<option value="errors-only" <?php selected( get_option( 'siteagent_log_level', 'all' ), 'errors-only' ); ?>><?php esc_html_e( 'Errors only', 'wp-siteagent' ); ?></option>
							<option value="none" <?php selected( get_option( 'siteagent_log_level', 'all' ), 'none' ); ?>><?php esc_html_e( 'Disabled', 'wp-siteagent' ); ?></option>
						</select>
					</div>
				</div>
			</div>
		</div>

		<div class="sa-settings-save">
			<?php submit_button( __( 'Save Settings', 'wp-siteagent' ), 'primary', 'submit', false, [ 'id' => 'sa-settings-save' ] ); ?>
		</div>

	</form>

	<!-- Danger Zone -->
	<div class="sa-card sa-card--danger">
		<div class="sa-card-header">
			<h3>⚠️ <?php esc_html_e( 'Danger Zone', 'wp-siteagent' ); ?></h3>
		</div>
		<div class="sa-card-body">
			<div class="sa-danger-row">
				<div>
					<strong><?php esc_html_e( 'Delete All Tokens', 'wp-siteagent' ); ?></strong>
					<p class="sa-hint"><?php esc_html_e( 'Immediately revokes all API access. Cannot be undone.', 'wp-siteagent' ); ?></p>
				</div>
				<button type="button" class="sa-btn sa-btn--danger" onclick="siteagent.dangerAction('delete_tokens', '<?php echo esc_attr( wp_create_nonce( 'siteagent_admin' ) ); ?>')">
					<?php esc_html_e( 'Delete All Tokens', 'wp-siteagent' ); ?>
				</button>
			</div>
			<div class="sa-danger-row">
				<div>
					<strong><?php esc_html_e( 'Delete All Audit Logs', 'wp-siteagent' ); ?></strong>
					<p class="sa-hint"><?php esc_html_e( 'Permanently deletes the entire audit log history.', 'wp-siteagent' ); ?></p>
				</div>
				<button type="button" class="sa-btn sa-btn--danger" onclick="siteagent.dangerAction('delete_logs', '<?php echo esc_attr( wp_create_nonce( 'siteagent_admin' ) ); ?>')">
					<?php esc_html_e( 'Delete All Logs', 'wp-siteagent' ); ?>
				</button>
			</div>
			<div class="sa-danger-row">
				<div>
					<strong><?php esc_html_e( 'Delete Data on Uninstall', 'wp-siteagent' ); ?></strong>
					<p class="sa-hint"><?php esc_html_e( 'When enabled, all plugin data will be removed when the plugin is deleted.', 'wp-siteagent' ); ?></p>
				</div>
				<label class="sa-toggle">
					<input type="checkbox" onchange="siteagent.saveOption('siteagent_delete_data_on_uninstall', this.checked ? 1 : 0)"
						<?php checked( get_option( 'siteagent_delete_data_on_uninstall', false ) ); ?> />
					<span class="sa-toggle-slider"></span>
				</label>
			</div>
		</div>
	</div>

	<?php require SITEAGENT_PATH . 'templates/partials/footer.php'; ?>
</div>
