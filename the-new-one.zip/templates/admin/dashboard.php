<?php
/**
 * Admin dashboard template.
 *
 * @package WP_SiteAgent
 */

defined( 'ABSPATH' ) || exit;

$plugin   = \WP_SiteAgent\Plugin::get_instance();
$registry = $plugin->get_abilities_registry();
$auth     = $plugin->get_auth_manager();
$audit    = $plugin->get_audit_logger();

$stats        = $audit->get_stats();
$tokens       = $auth->list_tokens( 0 );
$abilities    = $registry->get_all();
$recent_logs  = $audit->get_logs( [ 'per_page' => 10, 'page' => 1 ] );
$mcp_endpoint = rest_url( 'siteagent/v1/mcp/streamable' );
$site_url     = get_site_url();
$is_enabled   = (bool) get_option( 'siteagent_enabled', true );
$modules      = $plugin->get_modules();
$enabled_mods = $plugin->get_enabled_modules();
?>
<div class="sa-wrap">

	<?php require SITEAGENT_PATH . 'templates/partials/header.php'; ?>

	<div class="sa-dashboard">

		<!-- Status Bar -->
		<div class="sa-status-bar">
			<div class="sa-status-indicator <?php echo $is_enabled ? 'sa-status--active' : 'sa-status--inactive'; ?>">
				<span class="sa-status-dot"></span>
				<span class="sa-status-text">
					<?php echo $is_enabled ? esc_html__( 'MCP Server Active', 'wp-siteagent' ) : esc_html__( 'MCP Server Disabled', 'wp-siteagent' ); ?>
				</span>
			</div>
			<div class="sa-endpoint-url">
				<label><?php esc_html_e( 'Endpoint:', 'wp-siteagent' ); ?></label>
				<code id="sa-mcp-endpoint"><?php echo esc_url( $mcp_endpoint ); ?></code>
				<button type="button" class="sa-btn sa-btn--ghost sa-btn--sm" onclick="siteagent.copyText('sa-mcp-endpoint')">
					<?php esc_html_e( 'Copy', 'wp-siteagent' ); ?>
				</button>
			</div>
		</div>

		<!-- Stats Cards -->
		<div class="sa-stats-grid">
			<div class="sa-stat-card sa-stat--calls">
				<div class="sa-stat-icon">📊</div>
				<div class="sa-stat-content">
					<div class="sa-stat-value" id="stat-calls-today"><?php echo esc_html( number_format( $stats['calls_today'] ) ); ?></div>
					<div class="sa-stat-label"><?php esc_html_e( 'API Calls Today', 'wp-siteagent' ); ?></div>
				</div>
			</div>
			<div class="sa-stat-card sa-stat--tokens">
				<div class="sa-stat-icon">🔑</div>
				<div class="sa-stat-content">
					<div class="sa-stat-value" id="stat-tokens"><?php echo esc_html( count( $tokens ) ); ?></div>
					<div class="sa-stat-label"><?php esc_html_e( 'Active Tokens', 'wp-siteagent' ); ?></div>
				</div>
			</div>
			<div class="sa-stat-card sa-stat--abilities">
				<div class="sa-stat-icon">⚡</div>
				<div class="sa-stat-content">
					<div class="sa-stat-value" id="stat-abilities"><?php echo esc_html( count( $abilities ) ); ?></div>
					<div class="sa-stat-label"><?php esc_html_e( 'Abilities Registered', 'wp-siteagent' ); ?></div>
				</div>
			</div>
			<div class="sa-stat-card sa-stat--errors">
				<div class="sa-stat-icon">⚠️</div>
				<div class="sa-stat-content">
					<div class="sa-stat-value" id="stat-errors"><?php echo esc_html( number_format( $stats['errors_24h'] ) ); ?></div>
					<div class="sa-stat-label"><?php esc_html_e( 'Errors (24h)', 'wp-siteagent' ); ?></div>
				</div>
			</div>
		</div>

		<div class="sa-dashboard-body">

			<div class="sa-dashboard-main">

				<!-- Recent Audit Log -->
				<div class="sa-card">
					<div class="sa-card-header">
						<h2><?php esc_html_e( 'Recent Activity', 'wp-siteagent' ); ?></h2>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-audit' ) ); ?>" class="sa-link"><?php esc_html_e( 'View All →', 'wp-siteagent' ); ?></a>
					</div>
					<div class="sa-card-body sa-card--no-pad">
						<?php if ( empty( $recent_logs['logs'] ) ) : ?>
							<div class="sa-empty-state">
								<p><?php esc_html_e( 'No API calls yet. Connect an MCP client to get started.', 'wp-siteagent' ); ?></p>
							</div>
						<?php else : ?>
						<table class="sa-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Time', 'wp-siteagent' ); ?></th>
									<th><?php esc_html_e( 'Ability', 'wp-siteagent' ); ?></th>
									<th><?php esc_html_e( 'Status', 'wp-siteagent' ); ?></th>
									<th><?php esc_html_e( 'Duration', 'wp-siteagent' ); ?></th>
									<th><?php esc_html_e( 'IP', 'wp-siteagent' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $recent_logs['logs'] as $log ) : ?>
								<tr>
									<td class="sa-td--time"><?php echo esc_html( human_time_diff( strtotime( $log['executed_at'] ) ) ); ?> <?php esc_html_e( 'ago', 'wp-siteagent' ); ?></td>
									<td><code><?php echo esc_html( $log['ability_name'] ); ?></code></td>
									<td>
										<span class="sa-badge sa-badge--<?php echo esc_attr( $log['result_status'] ); ?>">
											<?php echo esc_html( $log['result_status'] ); ?>
										</span>
									</td>
									<td><?php echo esc_html( $log['duration_ms'] ? $log['duration_ms'] . 'ms' : '—' ); ?></td>
									<td class="sa-td--ip"><?php echo esc_html( $log['ip_address'] ); ?></td>
								</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
						<?php endif; ?>
					</div>
				</div>

				<!-- MCP Config Snippet -->
				<div class="sa-card">
					<div class="sa-card-header">
						<h2><?php esc_html_e( 'Connect your MCP Client', 'wp-siteagent' ); ?></h2>
					</div>
					<div class="sa-card-body">
						<?php require SITEAGENT_PATH . 'templates/partials/mcp-config-snippet.php'; ?>
					</div>
				</div>

			</div>

			<div class="sa-dashboard-sidebar">

				<!-- Module Status -->
				<div class="sa-card">
					<div class="sa-card-header">
						<h2><?php esc_html_e( 'Module Status', 'wp-siteagent' ); ?></h2>
					</div>
					<div class="sa-card-body sa-modules-grid">
						<?php
						$all_module_defs = [
							'content'     => [ 'icon' => '📝', 'label' => __( 'Content', 'wp-siteagent' ) ],
							'seo'         => [ 'icon' => '🔍', 'label' => __( 'SEO', 'wp-siteagent' ) ],
							'woocommerce' => [ 'icon' => '🛒', 'label' => __( 'WooCommerce', 'wp-siteagent' ) ],
							'diagnostics' => [ 'icon' => '🩺', 'label' => __( 'Diagnostics', 'wp-siteagent' ) ],
							'media'       => [ 'icon' => '🖼️', 'label' => __( 'Media', 'wp-siteagent' ) ],
							'users'       => [ 'icon' => '👥', 'label' => __( 'Users', 'wp-siteagent' ) ],
						];
						foreach ( $all_module_defs as $slug => $def ) :
							$is_active    = in_array( $slug, $enabled_mods, true );
							$module_obj   = $modules[ $slug ] ?? null;
							$ability_count = $module_obj ? count( $module_obj->get_ability_names() ) : 0;
							$available    = $slug !== 'woocommerce' || class_exists( 'WooCommerce' );
						?>
						<div class="sa-module-card <?php echo $is_active && $available ? 'sa-module--active' : 'sa-module--inactive'; ?>">
							<span class="sa-module-icon"><?php echo $def['icon']; // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
							<span class="sa-module-label"><?php echo esc_html( $def['label'] ); ?></span>
							<span class="sa-module-count"><?php echo esc_html( $ability_count ); ?> <?php esc_html_e( 'abilities', 'wp-siteagent' ); ?></span>
							<span class="sa-module-status">
								<?php if ( ! $available ) : ?>
									<span class="sa-badge sa-badge--disabled"><?php esc_html_e( 'Unavailable', 'wp-siteagent' ); ?></span>
								<?php elseif ( $is_active ) : ?>
									<span class="sa-badge sa-badge--success"><?php esc_html_e( 'Active', 'wp-siteagent' ); ?></span>
								<?php else : ?>
									<span class="sa-badge sa-badge--inactive"><?php esc_html_e( 'Disabled', 'wp-siteagent' ); ?></span>
								<?php endif; ?>
							</span>
						</div>
						<?php endforeach; ?>
					</div>
				</div>

				<!-- Quick Links -->
				<div class="sa-card">
					<div class="sa-card-header">
						<h2><?php esc_html_e( 'Quick Links', 'wp-siteagent' ); ?></h2>
					</div>
					<div class="sa-card-body">
						<ul class="sa-quick-links">
							<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-tokens' ) ); ?>">🔑 <?php esc_html_e( 'Generate API Token', 'wp-siteagent' ); ?></a></li>
							<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-abilities' ) ); ?>">⚡ <?php esc_html_e( 'Browse Abilities', 'wp-siteagent' ); ?></a></li>
							<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-audit' ) ); ?>">📋 <?php esc_html_e( 'View Audit Log', 'wp-siteagent' ); ?></a></li>
							<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-settings' ) ); ?>">⚙️ <?php esc_html_e( 'Settings', 'wp-siteagent' ); ?></a></li>
							<li><a href="https://modelcontextprotocol.io/docs" target="_blank" rel="noopener noreferrer">📖 <?php esc_html_e( 'MCP Documentation', 'wp-siteagent' ); ?></a></li>
						</ul>
					</div>
				</div>

			</div>
		</div>

	</div>

	<?php require SITEAGENT_PATH . 'templates/partials/footer.php'; ?>

</div>
