<?php
/**
 * Abilities list template.
 *
 * @package WP_SiteAgent
 */

defined( 'ABSPATH' ) || exit;

$plugin    = \WP_SiteAgent\Plugin::get_instance();
$registry  = $plugin->get_abilities_registry();
$abilities = $registry->get_all();

// Group by module prefix.
$grouped = [];
foreach ( $abilities as $name => $ability ) {
	$parts = explode( '/', $name, 2 );
	$prefix = $parts[0] . '/' . ( strstr( $parts[1] ?? '', '-', true ) ?: $parts[1] );

	// Group by module name derived from ability name.
	$mod = 'general';
	if ( str_contains( $name, 'woo-' ) ) {
		$mod = 'woocommerce';
	} elseif ( str_contains( $name, 'seo' ) || str_contains( $name, 'meta' ) || str_contains( $name, 'keyword' ) || str_contains( $name, 'sitemap' ) || str_contains( $name, 'broken' ) ) {
		$mod = 'seo';
	} elseif ( str_contains( $name, 'post' ) || str_contains( $name, 'taxonomy' ) ) {
		$mod = 'content';
	} elseif ( str_contains( $name, 'media' ) || str_contains( $name, 'alt' ) ) {
		$mod = 'media';
	} elseif ( str_contains( $name, 'user' ) || str_contains( $name, 'role' ) ) {
		$mod = 'users';
	} elseif ( str_contains( $name, 'site' ) || str_contains( $name, 'cron' ) || str_contains( $name, 'error' ) || str_contains( $name, 'transient' ) || str_contains( $name, 'db' ) || str_contains( $name, 'plugin' ) ) {
		$mod = 'diagnostics';
	}

	$grouped[ $mod ][ $name ] = $ability;
}

$module_labels = [
	'content'     => __( 'Content', 'wp-siteagent' ),
	'seo'         => __( 'SEO', 'wp-siteagent' ),
	'woocommerce' => __( 'WooCommerce', 'wp-siteagent' ),
	'diagnostics' => __( 'Diagnostics', 'wp-siteagent' ),
	'media'       => __( 'Media', 'wp-siteagent' ),
	'users'       => __( 'Users', 'wp-siteagent' ),
	'general'     => __( 'General', 'wp-siteagent' ),
];
?>
<div class="sa-wrap">
	<?php require SITEAGENT_PATH . 'templates/partials/header.php'; ?>

	<div class="sa-page-header">
		<h2><?php esc_html_e( 'Registered Abilities', 'wp-siteagent' ); ?></h2>
		<p class="sa-page-desc">
			<?php
			printf(
				/* translators: %d: ability count */
				esc_html__( '%d abilities registered and available via MCP.', 'wp-siteagent' ),
				count( $abilities )
			);
			?>
		</p>
	</div>

	<?php foreach ( $grouped as $module => $module_abilities ) : ?>
	<div class="sa-card sa-abilities-group">
		<div class="sa-card-header">
			<h3><?php echo esc_html( $module_labels[ $module ] ?? $module ); ?></h3>
			<span class="sa-badge sa-badge--neutral"><?php echo esc_html( count( $module_abilities ) ); ?></span>
		</div>
		<div class="sa-abilities-list">
			<?php foreach ( $module_abilities as $name => $ability ) :
				$is_public      = ! empty( $ability['annotations']['meta']['mcp']['public'] );
				$is_readonly    = ! empty( $ability['annotations']['readonly'] );
				$is_destructive = ! empty( $ability['annotations']['destructive'] );
			?>
			<div class="sa-ability-row">
				<div class="sa-ability-name">
					<code><?php echo esc_html( $name ); ?></code>
					<div class="sa-ability-tags">
						<?php if ( $is_public ) : ?><span class="sa-tag sa-tag--public"><?php esc_html_e( 'MCP', 'wp-siteagent' ); ?></span><?php endif; ?>
						<?php if ( $is_readonly ) : ?><span class="sa-tag sa-tag--readonly"><?php esc_html_e( 'Read Only', 'wp-siteagent' ); ?></span><?php endif; ?>
						<?php if ( $is_destructive ) : ?><span class="sa-tag sa-tag--destructive"><?php esc_html_e( 'Destructive', 'wp-siteagent' ); ?></span><?php endif; ?>
					</div>
				</div>
				<div class="sa-ability-desc"><?php echo esc_html( $ability['description'] ); ?></div>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
	<?php endforeach; ?>

	<?php require SITEAGENT_PATH . 'templates/partials/footer.php'; ?>
</div>
