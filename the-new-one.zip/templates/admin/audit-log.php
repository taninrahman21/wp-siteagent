<?php
/**
 * Audit log template.
 *
 * @package WP_SiteAgent
 */

defined( 'ABSPATH' ) || exit;

$plugin   = \WP_SiteAgent\Plugin::get_instance();
$audit    = $plugin->get_audit_logger();
$auth     = $plugin->get_auth_manager();
$registry = $plugin->get_abilities_registry();

// Current filters.
$filters = [
	'per_page'     => 25,
	'page'         => max( 1, absint( $_GET['paged'] ?? 1 ) ),
	'token_id'     => ! empty( $_GET['token_id'] ) ? absint( $_GET['token_id'] ) : null,
	'ability_name' => ! empty( $_GET['ability'] ) ? sanitize_text_field( wp_unslash( $_GET['ability'] ) ) : null,
	'status'       => ! empty( $_GET['status'] ) ? sanitize_text_field( wp_unslash( $_GET['status'] ) ) : null,
	'date_from'    => ! empty( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : null,
	'date_to'      => ! empty( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : null,
];

$filters = array_filter( $filters );
$filters['per_page'] = 25;

$result      = $audit->get_logs( $filters );
$logs        = $result['logs'];
$total       = $result['total'];
$pages       = $result['pages'];
$stats       = $audit->get_stats();
$tokens      = $auth->list_tokens( 0 );
$ability_names = array_keys( $registry->get_all() );
$nonce       = wp_create_nonce( 'siteagent_admin' );
?>
<div class="sa-wrap">
	<?php require SITEAGENT_PATH . 'templates/partials/header.php'; ?>

	<div class="sa-page-header">
		<h2><?php esc_html_e( 'Audit Log', 'wp-siteagent' ); ?></h2>
		<div class="sa-page-header-actions">
			<a href="<?php echo esc_url( rest_url( 'siteagent/v1/audit-log/export?nonce=' . $nonce ) ); ?>" class="sa-btn sa-btn--ghost">
				⬇ <?php esc_html_e( 'Export CSV', 'wp-siteagent' ); ?>
			</a>
		</div>
	</div>

	<!-- Summary Stats -->
	<div class="sa-audit-summary">
		<div class="sa-audit-stat">
			<strong><?php echo esc_html( number_format( $stats['calls_today'] ) ); ?></strong>
			<span><?php esc_html_e( 'Calls Today', 'wp-siteagent' ); ?></span>
		</div>
		<div class="sa-audit-stat">
			<strong><?php echo esc_html( $stats['error_rate'] ); ?>%</strong>
			<span><?php esc_html_e( 'Error Rate', 'wp-siteagent' ); ?></span>
		</div>
		<div class="sa-audit-stat">
			<strong><?php echo esc_html( $stats['avg_duration'] ); ?>ms</strong>
			<span><?php esc_html_e( 'Avg Duration', 'wp-siteagent' ); ?></span>
		</div>
		<div class="sa-audit-stat">
			<strong><?php echo esc_html( number_format( $total ) ); ?></strong>
			<span><?php esc_html_e( 'Shown (filtered)', 'wp-siteagent' ); ?></span>
		</div>
	</div>

	<!-- Filters Bar -->
	<div class="sa-card sa-filters-bar">
		<form method="get" id="sa-audit-filters" class="sa-form-inline">
			<input type="hidden" name="page" value="wp-siteagent-audit" />

			<select name="token_id" class="sa-select" onchange="this.form.submit()">
				<option value=""><?php esc_html_e( 'All Tokens', 'wp-siteagent' ); ?></option>
				<?php foreach ( $tokens as $token ) : ?>
				<option value="<?php echo esc_attr( $token['id'] ); ?>" <?php selected( $filters['token_id'] ?? '', $token['id'] ); ?>>
					<?php echo esc_html( $token['label'] ); ?>
				</option>
				<?php endforeach; ?>
			</select>

			<select name="ability" class="sa-select" onchange="this.form.submit()">
				<option value=""><?php esc_html_e( 'All Abilities', 'wp-siteagent' ); ?></option>
				<?php foreach ( $ability_names as $ability ) : ?>
				<option value="<?php echo esc_attr( $ability ); ?>" <?php selected( $filters['ability_name'] ?? '', $ability ); ?>>
					<?php echo esc_html( $ability ); ?>
				</option>
				<?php endforeach; ?>
			</select>

			<select name="status" class="sa-select" onchange="this.form.submit()">
				<option value=""><?php esc_html_e( 'All Statuses', 'wp-siteagent' ); ?></option>
				<option value="success" <?php selected( $filters['status'] ?? '', 'success' ); ?>><?php esc_html_e( 'Success', 'wp-siteagent' ); ?></option>
				<option value="error" <?php selected( $filters['status'] ?? '', 'error' ); ?>><?php esc_html_e( 'Error', 'wp-siteagent' ); ?></option>
				<option value="rate_limited" <?php selected( $filters['status'] ?? '', 'rate_limited' ); ?>><?php esc_html_e( 'Rate Limited', 'wp-siteagent' ); ?></option>
			</select>

			<input type="date" name="date_from" class="sa-input sa-input--sm" value="<?php echo esc_attr( $filters['date_from'] ?? '' ); ?>" onchange="this.form.submit()" />
			<input type="date" name="date_to" class="sa-input sa-input--sm" value="<?php echo esc_attr( $filters['date_to'] ?? '' ); ?>" onchange="this.form.submit()" />

			<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-siteagent-audit' ) ); ?>" class="sa-btn sa-btn--ghost sa-btn--sm"><?php esc_html_e( 'Reset', 'wp-siteagent' ); ?></a>
		</form>
	</div>

	<!-- Log Table -->
	<div class="sa-card">
		<div class="sa-card-body sa-card--no-pad">
			<?php if ( empty( $logs ) ) : ?>
			<div class="sa-empty-state">
				<p><?php esc_html_e( 'No log entries found for the current filters.', 'wp-siteagent' ); ?></p>
			</div>
			<?php else : ?>
			<table class="sa-table sa-audit-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Time', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'Ability', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'Status', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'Duration', 'wp-siteagent' ); ?></th>
						<th><?php esc_html_e( 'IP', 'wp-siteagent' ); ?></th>
						<th></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $logs as $log ) :
					$input_data = json_decode( $log['input_json'], true );
				?>
				<tr class="sa-log-row" id="log-row-<?php echo esc_attr( $log['id'] ); ?>">
					<td class="sa-td--time" title="<?php echo esc_attr( $log['executed_at'] ); ?>">
						<?php echo esc_html( human_time_diff( strtotime( $log['executed_at'] ) ) . ' ' . __( 'ago', 'wp-siteagent' ) ); ?>
					</td>
					<td><code><?php echo esc_html( $log['ability_name'] ); ?></code></td>
					<td>
						<span class="sa-badge sa-badge--<?php echo esc_attr( $log['result_status'] ); ?>">
							<?php echo esc_html( $log['result_status'] ); ?>
						</span>
					</td>
					<td><?php echo esc_html( $log['duration_ms'] !== null ? $log['duration_ms'] . 'ms' : '—' ); ?></td>
					<td><?php echo esc_html( $log['ip_address'] ); ?></td>
					<td>
						<button type="button" class="sa-btn sa-btn--ghost sa-btn--sm" onclick="siteagent.expandLogRow(<?php echo absint( $log['id'] ); ?>)">
							<?php esc_html_e( 'Details', 'wp-siteagent' ); ?>
						</button>
					</td>
				</tr>
				<tr class="sa-log-detail" id="log-detail-<?php echo esc_attr( $log['id'] ); ?>" style="display:none;">
					<td colspan="6">
						<div class="sa-log-detail-body">
							<div class="sa-log-detail-section">
								<strong><?php esc_html_e( 'Input:', 'wp-siteagent' ); ?></strong>
								<pre><?php echo esc_html( json_encode( $input_data, JSON_PRETTY_PRINT ) ); ?></pre>
							</div>
							<?php if ( $log['result_summary'] ) : ?>
							<div class="sa-log-detail-section">
								<strong><?php esc_html_e( 'Result:', 'wp-siteagent' ); ?></strong>
								<pre><?php echo esc_html( $log['result_summary'] ); ?></pre>
							</div>
							<?php endif; ?>
							<div class="sa-log-detail-meta">
								<span><?php esc_html_e( 'User Agent:', 'wp-siteagent' ); ?> <?php echo esc_html( $log['user_agent'] ?: '—' ); ?></span>
							</div>
						</div>
					</td>
				</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>
		</div>
	</div>

	<!-- Pagination -->
	<?php if ( $pages > 1 ) : ?>
	<div class="sa-pagination">
		<?php for ( $p = 1; $p <= $pages; $p++ ) : ?>
		<a href="<?php echo esc_url( add_query_arg( array_merge( $_GET, [ 'paged' => $p ] ) ) ); ?>"
			class="sa-page-link <?php echo ( $filters['page'] ?? 1 ) === $p ? 'sa-page-link--active' : ''; ?>">
			<?php echo esc_html( $p ); ?>
		</a>
		<?php endfor; ?>
	</div>
	<?php endif; ?>

	<?php require SITEAGENT_PATH . 'templates/partials/footer.php'; ?>
</div>
